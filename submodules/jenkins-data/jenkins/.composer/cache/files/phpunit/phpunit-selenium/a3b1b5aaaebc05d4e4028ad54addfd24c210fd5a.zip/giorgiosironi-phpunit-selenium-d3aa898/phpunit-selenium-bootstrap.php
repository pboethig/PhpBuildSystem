<?php
require_once __DIR__ . '/vendor/autoload.php';

require_once 'Tests/Selenium2TestCase/BaseTestCase.php';
PHPUnit_Extensions_Selenium2TestCase::shareSession(true);
