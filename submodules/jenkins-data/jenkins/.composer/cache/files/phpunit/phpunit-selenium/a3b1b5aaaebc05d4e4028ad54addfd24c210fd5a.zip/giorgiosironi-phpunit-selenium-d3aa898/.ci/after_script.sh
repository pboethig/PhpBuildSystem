killall php
killall python
killall java
